<?php
session_start();
$error=''; 
if (isset($_POST['submit'])) {
if (empty($_POST['username']) || empty($_POST['password'])) {
$error = "Nom d'utilisateur ou mot de passe invalide";
}
else
{

$username=$_POST['username'];
$password=$_POST['password'];


$connection = mysql_connect("localhost", "root", "");

// Protection de MySQL
$username = stripslashes($username);
$password = stripslashes($password);
$username = mysql_real_escape_string($username);
$password = mysql_real_escape_string($password);

$db = mysql_select_db("company", $connection);
//requete de recherche 
$query = mysql_query("select * from login where password='$password' AND username='$username'", $connection);
$rows = mysql_num_rows($query);
if ($rows == 1) {
$_SESSION['login_user']=$username; 
header("location: profile.php"); 
} else {
$error = "Nom d'utilisateur ou mot de passe est invalide";
}
mysql_close($connection);
}
}
?>
